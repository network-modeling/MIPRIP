######################## MIPRIP v2.0 #####################
miprip.run=function(mode=c("single", "dual", "multi"), group_names=c(), target_gene, num_repeats=10, num_cv=3, num_parameter=10, gurobi_parameter=list(timeLimit = 5, OutputFlag=0), X=expression, ES=network){

 #################################
 #########  Single-mode ##########
 #################################

	if(mode=="single"){

		cat("Testing the input data", "\n")
		#### Testing the datasets ###

 		# same order of samples, genes and TFs in all data sets
 		X=X[order(rownames(X), decreasing=FALSE),]
  	X=X[,order(colnames(X), decreasing=FALSE)]

  		ES=ES[order(rownames(ES), decreasing=FALSE),]
  		ES=ES[,order(colnames(ES), decreasing=FALSE)]


 		if(length(setdiff(rownames(X),rownames(ES))) > 0.5){
   			 print(paste("Warning:",length(setdiff(rownames(X),rownames(ES))), "genes aren't contained in the generic regulatory network:",collapse = " "))
    		#print(paste(setdiff(rownames(X),rownames(ES)),collapse = ", "))
   			 X <- X[rownames(X) %in% rownames(ES),]
    		 ES <- ES[rownames(ES) %in% rownames(X),]
  		}


  		if(exists("Act")==TRUE){
  		#if(isTRUE(length(Act)==0)==FALSE){
  			Act=Act[order(rownames(Act), decreasing=FALSE),]
  			Act=Act[,order(colnames(Act), decreasing=FALSE)]
  			Act=Act[,colnames(Act) %in% colnames(X)]

  			#test if samples in expression matrix X and activity matrix Act are the same
  			if(length(colnames(Act)) != length(colnames(X)) && length(colnames(X)[colnames(X) %in% colnames(Act)])!=length(colnames(Act))){
    			print("Error: Number of samples provided in activity matrix and expression matrix differ")
    			return()
  			}

  			# test if set of TFs in edgestrength_matrix equals set of TFs in activity_matrix
  			# if not error
  			if(length(setdiff(rownames(Act),colnames(ES))) > 0.5){
    			print(paste("Error:",length(setdiff(rownames(Act),colnames(ES))), " TFs aren't contained in edgestrength matrix:",collapse = " "))
    			print(paste(setdiff(rownames(Act),colnames(ES)),collapse = ", "))
    			return()
  			}
  	} else {
  		#### Calculating the activity matrix #####
  		cat("Activity matrix calculation", "\n")

  	  # deleting samples with NA value for the target gene
  	  X=X[,!is.na(X[target_gene,])==T]

  	  gene=as.vector(ES[target_gene,])
  	  es=rep(0, length(colnames(ES)))

  	  ES[target_gene,]=as.vector(es)

  	  X[is.na(X)] <- 0

  	  Act<-t(ES) %*% as.matrix(X)

  	  for (jj in 1:length(rownames(Act))){
  	    Act[jj,]=Act[jj,]/sum(ES[,jj])
  	  }

  	  ES[target_gene,]=as.vector(gene)


  	  Act <- Act[which(colSums(ES) > 0),]
  	  ES <- ES[,rownames(Act)]
  	}


 		cat("Using MIPRIP2 in single-mode", "\n")

		results_group1=miprip.modelling(group=colnames(X), repeats=num_repeats, num_fold_cross_validation=num_cv, max_parameter_limit=num_parameter, sample_size=length(colnames(X)), Act = Act, X=X, ES=ES, target_gene=target_gene, params=gurobi_parameter)

    	result_complete_group1=results_group1$result_complete
    	predictions_group1=results_group1$predictions
    	frequency_group1=results_group1$table_complete

		performance_single=c()
    	for(aa in 1:(num_cv*num_repeats)){
    		performance_single=cbind(performance_single, round(as.numeric(result_complete_group1[[aa]]$correlation), digits=2))
    		colnames(performance_single)[aa]=aa
    	}
    	rownames(performance_single)=1:num_parameter


    	save(result_complete_group1, performance_single, frequency_group1, predictions_group1, file=paste("MIPRIP_results_singleMode_", target_gene, ".RData", sep=""))

    	pdf(paste("Performance_MIPRIP_singleMode_", target_gene, ".pdf", sep=""))
    	boxplot(t(performance_single), col="grey", xlab="Number parameters", ylab="MIPRIP performance", main=paste("MIPRIP performance ", target_gene, sep=""))
    	dev.off()

    	cat("Output written to ", paste("MIPRIP_results_singleMode_", target_gene, ".RData", sep=""), "\n")

	}

	########################################
  	############### Dual-mode ##############
  	########################################

    if(mode=="dual"){

    	cat("Using MIPRIP2 in dual-mode", "\n")

    	performance_dual=list()
    	frequency_dual=list()
    	multiple_datasets=X

    	if(exists("Act")==TRUE){
    	  multiple_Act=Act
    	}

    	for (gr in 1:2){

    		name=group_names[gr]


    		cat("Testing the input data", "\n")

    		X=multiple_datasets[[gr]]

    		#### Testing the datasets ###

 			# same order of samples, genes and TFs in all data sets
 		 	  X=X[order(rownames(X), decreasing=FALSE),]
  			X=X[,order(colnames(X), decreasing=FALSE)]

  			ES=ES[order(rownames(ES), decreasing=FALSE),]
  			ES=ES[,order(colnames(ES), decreasing=FALSE)]


 			if(length(setdiff(rownames(X),rownames(ES))) > 0.5){
   				 print(paste("Warning:",length(setdiff(rownames(X),rownames(ES))), "genes aren't contained in the generic regulatory network:",collapse = " "))
    			#print(paste(setdiff(rownames(X),rownames(ES)),collapse = ", "))
   				 X <- X[rownames(X) %in% rownames(ES),]
    			 ES <- ES[rownames(ES) %in% rownames(X),]
  			}


  			if(exists("multiple_Act")==TRUE){
  				Act=multiple_Act[[gr]]
  				Act=Act[order(rownames(Act), decreasing=FALSE),]
  				Act=Act[,order(colnames(Act), decreasing=FALSE)]
  				Act=Act[,colnames(Act) %in% colnames(X)]

  				#test if samples in expression matrix X and activity matrix Act are the same
  				if(length(colnames(Act)) != length(colnames(X)) && length(colnames(X)[colnames(X) %in% colnames(Act)])!=length(colnames(Act))){
    				print("Error: Number of samples provided in activity matrix and expression matrix differ")
    				return()
  				}

  				# test if set of TFs in edgestrength_matrix equals set of TFs in activity_matrix
  				# if not error
  				if(length(setdiff(rownames(Act),colnames(ES))) > 0.5){
    				print(paste("Error:",length(setdiff(rownames(Act),colnames(ES))), " TFs aren't contained in edgestrength matrix:",collapse = " "))
    				print(paste(setdiff(rownames(Act),colnames(ES)),collapse = ", "))
    				return()
  				}

  			} else {

  				#### Calculating the activity matrix #####
  				cat("Activity matrix calculation", "\n")

  			  X=X[,!is.na(X[target_gene,])==T]

  				gene=as.vector(ES[target_gene,])
  				es=rep(0, length(colnames(ES)))

  				ES[target_gene,]=as.vector(es)

  				X[is.na(X)] <- 0

  				Act<-t(ES) %*% as.matrix(X)

  				for (jj in 1:length(rownames(Act))){
    				Act[jj,]=Act[jj,]/sum(ES[,jj])
  				}

  				ES[target_gene,]=as.vector(gene)

  				Act <- Act[which(colSums(ES) > 0),]
  				ES <- ES[,rownames(Act)]
  			}

    		cat("Modelling ", name, "\n")
    		results=miprip.modelling(group=colnames(X), repeats=num_repeats, num_fold_cross_validation=num_cv, max_parameter_limit=num_parameter, sample_size=length(colnames(X)), Act = Act, X=X, ES=ES, target_gene=target_gene, params=gurobi_parameter)

    		results_complete_group1=results$result_complete
    		predictions_group1=results$predictions
    		frequency_group1=results$table_complete

    		frequency_dual[[gr]]=frequency_group1

    		performance_single=c()
    		for(aa in 1:(num_cv*num_repeats)){
    			performance_single=cbind(performance_single, round(as.numeric(results_complete_group1[[aa]]$correlation), digits=2))
    			colnames(performance_single)[aa]=aa
    		}
    		rownames(performance_single)=1:num_parameter

    		pdf(paste("Performance_MIPRIP_dualMode_", name, "_", target_gene, ".pdf", sep=""))
    		boxplot(t(performance_single), col="grey", xlab="Number parameters", ylab="MIPRIP performance", main=paste("MIPRIP performance ", target_gene, " ", name, sep=""))
    		dev.off()

    		performance_dual[[gr]]=performance_single

    		save(results_complete_group1, frequency_group1, predictions_group1, performance_single, file=paste("MIPRIP_results_dualMode_",target_gene, "_", name, ".RData", sep=""))

    	}

    	###### Boxplot of all performances #####
    	performance_all=c()

    	for (pp in 1:length(performance_dual)){
    		performance_all=cbind(performance_all, as.vector(performance_dual[[pp]]))
    	}

    	pdf(paste("Performance_MIPRIP_dualMode_", group_names[1], "_", group_names[2], "_", target_gene, ".pdf", sep=""))
    	par(las=2, cex.axis=0.75, pch=20)
    	boxplot(performance_all, col="grey", names=group_names, ylab="MIPRIP performance", main=paste("MIPRIP performance ", target_gene, sep=""))
    	dev.off()

		################ Fishers Exact Test ##########

		cat("Calculating Fisher's Exact Text", "\n")
		tfs_vector=colnames(ES)[ES[target_gene,]>0]

		fisher=matrix(nrow=length(tfs_vector), ncol=5)

		for (ii in 1:length(tfs_vector)){
			A=sum(as.numeric(frequency_dual[[1]][ii,]))
			B=(num_cv*num_repeats*num_parameter)-A
			C=sum(as.numeric(frequency_dual[[2]][ii,]))
			D=(num_cv*num_repeats*num_parameter)-C
			x=matrix(c(A,C,B,D),2,2)
			result=fisher.test(x, alternative="two.sided")
			fisher[ii,1]=tfs_vector[ii]
			fisher[ii,2]=A
			fisher[ii,3]=C
			fisher[ii,4]=result$p.value
		}

		fisher[,5] = p.adjust(as.numeric(fisher[,4]), method="BH");
		fisher=fisher[order(as.numeric(fisher[,5]), decreasing=F),]

		colnames(fisher)=c("TF", "Frequency_group1", "Frequency_group2", "p-value", "p-value_BH")

		significant_hits=fisher[fisher[,5]<0.05,]

		cat("Significant Hits of ", target_gene, "\n")
		print(significant_hits)

    	write.table(significant_hits, paste("Significant_regulators_", target_gene, "_", group_names[1], "_vs_", group_names[2], ".txt", sep=""), sep="\t", col.names=T, row.names=F, quote=F)

  	}

  	#########################################
  	############### Multi-mode ##############
  	#########################################

	if(mode=="multi"){

    	cat("Using MIPRIP2 in multi-mode", "\n")

    	performance_multi=list()
    	frequency_multi=list()

    	multiple_datasets=X

    	if(exists("Act")==TRUE){
    	  multiple_Act=Act
    	}

    	for (gr in 1:length(multiple_datasets)){

    		name=group_names[gr]

    		cat("Testing the input data", "\n")

    		X=multiple_datasets[[gr]]

    		#### Testing the datasets ###

 			# same order of samples, genes and TFs in all data sets
 		 	 X=X[order(rownames(X), decreasing=FALSE),]
  			X=X[,order(colnames(X), decreasing=FALSE)]

  			ES=ES[order(rownames(ES), decreasing=FALSE),]
  			ES=ES[,order(colnames(ES), decreasing=FALSE)]


 			if(length(setdiff(rownames(X),rownames(ES))) > 0.5){
   				 print(paste("Warning:",length(setdiff(rownames(X),rownames(ES))), "genes aren't contained in the generic regulatory network:",collapse = " "))
    			#print(paste(setdiff(rownames(X),rownames(ES)),collapse = ", "))
   				 X <- X[rownames(X) %in% rownames(ES),]
    			 ES <- ES[rownames(ES) %in% rownames(X),]
  			}


  			if(exists("multiple_Act")==TRUE){
  				Act=multiple_Act[[gr]]
  				Act=Act[order(rownames(Act), decreasing=FALSE),]
  				Act=Act[,order(colnames(Act), decreasing=FALSE)]
  				Act=Act[,colnames(Act) %in% colnames(X)]

  				#test if samples in expression matrix X and activity matrix Act are the same
  				if(length(colnames(Act)) != length(colnames(X)) && length(colnames(X)[colnames(X) %in% colnames(Act)])!=length(colnames(Act))){
    				print("Error: Number of samples provided in activity matrix and expression matrix differ")
    				return()
  				}

  				# test if set of TFs in edgestrength_matrix equals set of TFs in activity_matrix
  				# if not error
  				if(length(setdiff(rownames(Act),colnames(ES))) > 0.5){
    				print(paste("Error:",length(setdiff(rownames(Act),colnames(ES))), " TFs aren't contained in edgestrength matrix:",collapse = " "))
    				print(paste(setdiff(rownames(Act),colnames(ES)),collapse = ", "))
    				return()
  				}

  			} else {

  				#### Calculating the activity matrix #####
  				cat("Activity matrix calculation", "\n")

  			  X=X[,!is.na(X[target_gene,])==T]

  				gene=as.vector(ES[target_gene,])
  				es=rep(0, length(colnames(ES)))

  				ES[target_gene,]=as.vector(es)

  				X[is.na(X)] <- 0

  				Act<-t(ES) %*% as.matrix(X)

  				for (jj in 1:length(rownames(Act))){
    				Act[jj,]=Act[jj,]/sum(ES[,jj])
  				}

  				ES[target_gene,]=as.vector(gene)


  				Act <- Act[which(colSums(ES) > 0),]
  				ES <- ES[,rownames(Act)]
  			}

    		cat("Modelling ", name, "\n")
    		results=miprip.modelling(group=colnames(X), repeats=num_repeats, num_fold_cross_validation=num_cv, max_parameter_limit=num_parameter, sample_size=length(colnames(X)), Act = Act, X=X, ES=ES, target_gene=target_gene, params=gurobi_parameter)

    		results_complete_group1=results$result_complete
    		predictions_group1=results$predictions
    		frequency_group1=results$table_complete

    		frequency_multi[[gr]]=frequency_group1

    		performance_single=c()
    		for(aa in 1:(num_cv*num_repeats)){
    			performance_single=cbind(performance_single, round(as.numeric(results_complete_group1[[aa]]$correlation), digits=2))
    			colnames(performance_single)[aa]=aa
    		}
    		rownames(performance_single)=1:num_parameter

    		pdf(paste("Performance_MIPRIP_multiMode_", name, "_", target_gene, ".pdf", sep=""))
    		boxplot(t(performance_single), col="grey", xlab="Number parameters", ylab="MIPRIP performance", main=paste("MIPRIP performance ", target_gene, " ", name, sep=""))
    		dev.off()

    		performance_multi[[gr]]=performance_single

    		save(results_complete_group1, frequency_group1, predictions_group1, performance_single, file=paste("MIPRIP_results_multiMode_",target_gene, "_", name, ".RData", sep=""))

    	}

    	###### Boxplot of all performances #####
    	performance_all=c()

    	for (pp in 1:length(performance_multi)){
    		performance_all=cbind(performance_all, as.vector(performance_multi[[pp]]))
    	}

    	pdf(paste("Performance_MIPRIP_multiMode_allDatasets_", target_gene, ".pdf", sep=""))
    	par(las=2, cex.axis=0.75, pch=20)
    	boxplot(performance_all, col="grey", names=group_names, ylab="MIPRIP performance", main=paste("MIPRIP performance ", target_gene, sep=""))
    	dev.off()

    	####### common regulators ######
    	cat("Common regulators of all groups/datasets", "\n")

    	tfs<-colnames(ES)[ES[target_gene,]>0]

    	overall_frequency=matrix(nrow=length(tfs), ncol=length(group_names))
    	colnames(overall_frequency)=group_names
    	rownames(overall_frequency)=tfs

    	for (rr in 1:length(group_names)){
    		for (tt in 1:length(tfs)){
    			overall_frequency[tt,rr]=sum(as.numeric(frequency_multi[[rr]][tt,]))
    		}
    	}

    	overall_frequency2=overall_frequency

    	for (rr in 1:length(group_names)){
    		relrank=overall_frequency[,rr]
  			relrank=relrank[order(relrank, decreasing=T)]
  			relrank=relrank*(-1)
  			r=rank(relrank)

			for (tf in tfs){
  				overall_frequency2[tf,rr]=as.numeric(r[tf])/length(tfs)
  			}
		}

		rankproducts = NULL
		for (tf in tfs){
			rp=prod(as.numeric(overall_frequency2[tf,]))
  			rankproducts = c(rankproducts, rp)
  		}

		names(rankproducts)=tfs
		rank_product=sort(rankproducts)

		############## Permutations ##############
		res=c()
		x=1:length(tfs)

		for (jj in 1:10000){
			y=sample(x, length(group_names), replace=TRUE)
			y=y/length(tfs)
			permu=prod(as.numeric(y), na.rm=F)
			res=c(res, permu)
		}

		test=matrix(nrow=length(tfs), ncol=3)
		for (ii in 1:length(tfs)){
  			test[ii,1]=names(rank_product)[ii]
  			test[ii,2]=as.numeric(rank_product[ii])
  			test[ii,3]=(length(res[res<=as.numeric(rank_product[ii])])/10000)/ii
		}

		colnames(test)=c("Regulator", "Rank product", "E-value")
		#test[,4]=p.adjust(as.numeric(test[,3]), method="BH")

    	write.table(test, paste("Common_regulators_", target_gene, "rankProd.txt", sep=""), sep="\t", col.names=T, row.names=F, quote=F)

    	##### group specific regulators #######
    	cat("Calculating the group/dataset-specific regulators", "\n")

    	tfs<-colnames(ES)[ES[target_gene,]>0]

		for (ll in 1:length(group_names)){
			test=frequency_multi[[ll]]

			rest=frequency_multi[-ll]
			others=do.call(cbind, rest)

			de_wil <-matrix(nrow=length(tfs), ncol=3)

			dwii = 1

			for (ii in 1:length(tfs)) {
	 			s=test[rownames(test)==tfs[ii],]
	 			r=others[rownames(others)==tfs[ii],]
        		this <- wilcox.test(as.numeric(s),as.numeric(r), paired = FALSE, alternative="greater");
        		de_wil[dwii,1]=tfs[ii];
        		de_wil[dwii,2]=this$p.value;
        		dwii = dwii + 1
			}

			de_wil[,3] = p.adjust(as.numeric(de_wil[,2]), method="BH");
			de_wil=de_wil[order(as.numeric(de_wil[,2])),]

			colnames(de_wil)=c("TF", "p-value", "p-value_BH")

			write.table(de_wil, file=paste("Results_Wilcoxon_", group_names[ll], "_vs_allOthers_", target_gene, ".csv", sep=""), sep="\t", col.names=TRUE, row.names=FALSE, quote=FALSE)

    	}

    	save(frequency_multi, performance_multi, file=paste("MIPRIP_results_multiMode_",target_gene,".RData", sep=""))

    	cat("Output written to ", paste("MIPRIP_results_multiMode_", target_gene, ".RData", sep=""), "\n")
    }

  	cat("Modelling finished", "\n")
}


################################ Modelling ###################################
miprip.modelling <- function(group, repeats, num_fold_cross_validation, max_parameter_limit, sample_size, Act, X, ES, target_gene, params){

	samples_group=sample(group, sample_size, replace=FALSE)

	expression_matrix = X[,colnames(X) %in% samples_group]
	activity_matrix = Act[,colnames(Act) %in% samples_group]
	edgestrength_matrix = ES

	result_complete=c()
	predictions=c()
	table_complete=c()

	##### Options #####
	big_m = 1000

	b_bas = "b_bas"
	b_pre = "b_"
	x_pre = "x_"

	for (ll in 1:repeats){
	cat("Repeat", ll, "\n")

	########################## Sample set
	#select #num_sample_exclude samples randomly
	sample_pool = colnames(expression_matrix)
	num_sample_exclude = length(sample_pool) / num_fold_cross_validation
	num_sample_exclude = floor(num_sample_exclude)

	iteration_vector = c()
	sample_iteration_vector = c()

	iteration=0
	while(length(sample_pool) >= num_sample_exclude){
  		iteration = iteration + 1
  		iteration_vector = c(iteration_vector,iteration)

  		selected_samples = sample(sample_pool,num_sample_exclude, replace=FALSE)
  		selected_samples_term = paste(selected_samples, collapse = ",")
  		sample_iteration_vector = c(sample_iteration_vector,selected_samples_term)

  		selected_samples_index = which(sample_pool %in% selected_samples)
  		sample_pool = sample_pool[-selected_samples_index]
	}

	iteration_sample_df = data.frame(iteration_vector,sample_iteration_vector)
	colnames(iteration_sample_df) = c("iteration","samples")

	#expression index
	target_gene_expression_index = which(rownames(expression_matrix) == target_gene)

 	#determine number of parameters
 	num_parameter = 0
  	num_exp_parameter = 0
  	num_cons_parameter = 0
  	num_error_terms = 0
  	parameter_limit = 0

  	constraint_matrix_colnames = c()
  	binary_parameters = c()
  	exp_parameters = c()
  	tf_vector = c()

   	#b_bas
    num_parameter = num_parameter + 1
    constraint_matrix_colnames = c(constraint_matrix_colnames,b_bas)

  	#TFs
    target_gene_tf_index = which(edgestrength_matrix[target_gene,] > 0)
    tf_vector = as.vector(colnames(edgestrength_matrix)[target_gene_tf_index])

      num_parameter = num_parameter + (2 * length(tf_vector))
      num_exp_parameter = num_exp_parameter + length(tf_vector)
      num_cons_parameter = num_cons_parameter + (2 * length(tf_vector))

      #construct b_tf and x_tf variables
      for(i in 1:length(tf_vector)){
        tf = tf_vector[i]
        b_tf = paste("b_",tf,sep="")
        x_tf = paste("x_",tf,sep="")
        constraint_matrix_colnames = c(constraint_matrix_colnames,b_tf)
        constraint_matrix_colnames = c(constraint_matrix_colnames,x_tf)
        binary_parameters = c(binary_parameters,x_tf)
        exp_parameters = c(exp_parameters,b_tf)
      }

      if(num_exp_parameter < max_parameter_limit){
   	 	parameter_limit = num_exp_parameter
  	  }else{
    	parameter_limit = max_parameter_limit
      }

  exp_parameter_occ = rep(0,length(exp_parameters))
  parameter_occurrende_df = data.frame(exp_parameters,exp_parameter_occ)
  colnames(parameter_occurrende_df) = c("parameter","occurrence")

  gene_cor_pred_df =  NULL

  total_cor_pred_list = list()
  total_cor_meas_list = list()

###########################################################################

  #iterate over all samples sets for cross validation
	cat("Cross-validation", "\n")

	for(q in 1:length(rownames(iteration_sample_df))){
    current_cross_validation = q

    cat(current_cross_validation, "\n")

    result.table <- as.data.frame(cbind("TF"=1,"Betas_TF"=1,"Amount TF"=1, "correlation"=1))

    pred=matrix(nrow=num_sample_exclude, ncol=max_parameter_limit+1)

    current_predict_sample_term = as.character(iteration_sample_df[q,2])
    current_predict_samples = as.vector(strsplit(current_predict_sample_term,",")[[1]])

    #get training samples
    training_samples_index = which(!colnames(expression_matrix) %in% current_predict_samples)
    training_samples = as.vector(colnames(expression_matrix)[training_samples_index])

    #construct global result matrix
    result_matrix_num_rows = parameter_limit
    result_matrix_num_cols = length(exp_parameters) + 1
    result_parameter_matrix = matrix(0,result_matrix_num_rows,result_matrix_num_cols)
    colnames(result_parameter_matrix) = c("parameter_limit",exp_parameters)
    parameter_limit_vector = as.vector(seq(1:parameter_limit))
    result_parameter_matrix[,"parameter_limit"] = parameter_limit_vector
    result_parameter_matrix = as.matrix(result_parameter_matrix)

    ###########################################################################
    #set up model for all training samples

    current_model_samples = training_samples

    if (num_fold_cross_validation==1){
    current_model_samples=current_predict_samples
    }

    #determine which model samples have valid expression values
    current_model_sample_index = which(colnames(expression_matrix) %in% current_model_samples)
    reduced_expression_matrix = expression_matrix[,current_model_sample_index]

    current_model_sample_valid_expression_value_index = which(!is.na(reduced_expression_matrix[target_gene_expression_index,]))
    current_model_samples = as.vector(colnames(reduced_expression_matrix)[current_model_sample_valid_expression_value_index])

    #############################################################

    current_model_matrix_colnames = c(constraint_matrix_colnames)

    #define error terms
    for(i in 1:length(current_model_samples)){
      current_sample = current_model_samples[i]
      sample_error_term = paste("e_",current_sample,sep="")
      current_model_matrix_colnames = c(current_model_matrix_colnames,sample_error_term)
    }
    num_error_terms = length(current_model_samples)

   #############################################################
    #define number of constraints
    # x_TF_1 + x_TF_2 + ... <= total_parameter_limit
    # b_TF - 1000 x_TF <= 0
    # b_TF + 1000 x_TF >= 0

    # 2 constraints for each sample (abs. value)
    # 1 for total parameter limit

    num_constraints = num_cons_parameter + (2 * length(current_model_samples)) + 1
    total_column_number = num_parameter + num_error_terms

     #############################################################
    ###define model variables per iteration
    #right-hand-side
    rhs = c()
    #objective vector
    obj = c()
    #fill with num_parameter x 0
    obj = c(obj,rep(0,total_column_number))
    #model sense
    modelsense = "min"
    #sense vector
    sense = c()
    #variable type
    vtype = c(rep("C",total_column_number))
    #"C" (continuous), "B" (binary), "I" (integer), "S" (semi-continuous), or "N" (semi-integer)
    #lower bound
    lb = c(rep(0,total_column_number))
    #upper bound
    ub = c(rep(0,total_column_number))
    #constraint matrix

    A <- matrix(0,nrow=num_constraints,ncol=total_column_number,byrow=T)

    colnames(A) = current_model_matrix_colnames
    names(obj) = current_model_matrix_colnames
    names(lb) = current_model_matrix_colnames
    names(ub) = current_model_matrix_colnames
    names(vtype) = current_model_matrix_colnames

    #iterate over samples and create sample constraints
    for(i in 1:length(current_model_samples)){
      current_sample = current_model_samples[i]
      #create error term
      sample_error_term = paste("e_",current_sample,sep="")
      sample_error_term_index = which(colnames(A) == sample_error_term)
      #add value to obj
      sample_error_obj_index = which(names(obj) == sample_error_term)
      obj[sample_error_obj_index] = 1

      #add lb
      sample_error_lb_index = which(names(lb) == sample_error_term)
      lb[sample_error_lb_index] = 0

      #add ub
      sample_error_ub_index = which(names(ub) == sample_error_term)
      ub[sample_error_ub_index] = big_m

      #sample expression value
      current_sample_expression_index = which(colnames(expression_matrix) == current_sample)
      current_sample_expression_value = as.numeric(expression_matrix[target_gene_expression_index,current_sample_expression_index])
      #print(current_sample_expression_value)
      current_sample_expression_negative_value = -(current_sample_expression_value)
      #add expression values (+ and -) to rhs vector
      rhs = c(rhs,current_sample_expression_value,current_sample_expression_negative_value)
      #add sense for each expression vector
      sense = c(sense,"<=","<=")

      #b_bas
        #always 1
        #add to constraint_matrix
        A[((2*i)-1),b_bas] = 1
        A[(2*i),b_bas] = -1

        #add bounds
        lb[b_bas] = -big_m
        ub[b_bas] = big_m

      #TF
        if(length(tf_vector) > 0){
          for(m in 1:length(tf_vector)){
            tf = tf_vector[m]

            b_tf = paste(b_pre,tf,sep="")
            x_tf = paste(x_pre,tf,sep="")

            current_sample_tf_value = 0

            current_sample_tf_index = which(colnames(activity_matrix) == current_sample)
            if(length(current_sample_tf_index) > 0){
              current_tf_index = which(rownames(activity_matrix) == tf)
              if(!is.na(activity_matrix[current_tf_index,current_sample_tf_index])){
                current_sample_tf_value = as.numeric(activity_matrix[current_tf_index,current_sample_tf_index])*edgestrength_matrix[which(rownames(edgestrength_matrix)==target_gene),which(colnames(edgestrength_matrix) == tf)]
              }
            }

            #add to constraint_matrix
            A[((2*i)-1),b_tf] = current_sample_tf_value
            A[(2*i),b_tf] = -current_sample_tf_value

            #add variable type
            vtype[x_tf] = "B"

            #add bounds
            lb[b_tf] = -big_m
            ub[b_tf] = big_m

            lb[x_tf] = 0
            ub[x_tf] = 1

          }
        }

	#add error terms
      A[((2*i)-1),sample_error_term_index] = -1
      A[(2*i),sample_error_term_index] = -1

    }

    ###########################################################
    #determine current row_index
    current_row_index = (2 * length(current_model_samples)) + 1
    #add constraints

    #TF
      if(length(tf_vector) > 0){
        for(m in 1:length(tf_vector)){
          tf = tf_vector[m]

          b_tf = paste(b_pre,tf,sep="")
          x_tf = paste(x_pre,tf,sep="")

          #add 1 for exp parameter
          A[current_row_index,b_tf] = 1
          #add #big_m for binary parameter
          A[current_row_index,x_tf] = -big_m
          current_row_index = current_row_index + 1
          #repeat with minus sign
          A[current_row_index,b_tf] = 1
          A[current_row_index,x_tf] = big_m

          sense = c(sense,"<=",">=")
          rhs = c(rhs,0,0)

          current_row_index = current_row_index + 1
        }
      }

	#add constraint limit for all binary parameters
    for(k in 1:length(binary_parameters)){
      binary_parameter = binary_parameters[k]
      binary_parameter_index = which(colnames(A) == binary_parameter)
      A[current_row_index,binary_parameter_index] = 1
    }

    #add sense to last row for parameter_limit
    sense = c(sense,"<=")

    for(o in 1:parameter_limit){
      current_parameter_limit = as.numeric(o)
      current_result_parameter_index = which(result_parameter_matrix[,"parameter_limit"] == current_parameter_limit)
      #last constraint : sum of all binary variable <= parameter_limit
      #add current parameter_limit to rhs
      rhs[current_row_index] = current_parameter_limit

      model <- list()
      model$A          <- A
      model$obj        <- obj
      model$modelsense <- modelsense
      model$rhs        <- rhs
      model$sense      <- sense
      model$lb         <- lb
      model$ub         <- ub
      model$vtype      <- vtype

      #params <- list(timeLimit = 3600,ResultFile=file_name)
      #params <- list(timeLimit = 600,OutputFlag=0)
      #params <- list(timeLimit = 600,OutputFlag=1)
      result <- gurobi(model, params)

      ################################################################
      #Evaluate single results

      result_var_vector = c()
      result_value_vector = c()

      #find indices in current_model_matrix_colnames

      #TF
      	top_hits=c()

        if(length(tf_vector) > 0){
          for(m in 1:length(tf_vector)){
            tf = tf_vector[m]

            b_tf = paste(b_pre,tf,sep="")
            x_tf = paste(x_pre,tf,sep="")

            b_index = which(current_model_matrix_colnames == b_tf)
            b_value = as.numeric(result$x[b_index])

        	x_index = which(current_model_matrix_colnames == x_tf)
            x_value = as.numeric(result$x[x_index])

            if(round(x_value,1) == 1){
              top_hits=c(top_hits, tf)
              result_var_vector = c(result_var_vector,b_tf)
              result_value_vector = c(result_value_vector,b_value)
              parameter_index = which(colnames(result_parameter_matrix) == b_tf)
              result_parameter_matrix[current_result_parameter_index,parameter_index] = b_value
            }
          }
        }

    id.tf=which(colnames(ES) %in% top_hits)

    v=rep(0, max_parameter_limit)

    if(o==1){
    result_parameter_matrix2=cbind(result_parameter_matrix, v)
    colnames(result_parameter_matrix2)[length(tf_vector)+2]="b_bas"
    result_parameter_matrix2[o,length(tf_vector)+2]=result$x[1]
    } else {result_parameter_matrix2[o,length(tf_vector)+2]=result$x[1]
    result_parameter_matrix2[o,1:(length(tf_vector)+1)]=result_parameter_matrix[o,]}

    #######################################################################################################
	#Run Estimation of Prediction Performance:

	beta.values=result_parameter_matrix2[o,2:(length(tf_vector)+2)][result_parameter_matrix2[o,2:(length(tf_vector)+2)]!=0]

    X_val=expression_matrix[,colnames(expression_matrix) %in% current_predict_samples]
  	Act_val<-activity_matrix[,colnames(activity_matrix) %in% current_predict_samples]

    cell_line_name <- colnames(expression_matrix)
    id.cellline <- c(1:length(colnames(expression_matrix)))
    names(id.cellline) <- cell_line_name

    g_real_all <- c()
    prediction_all <- c()
    cor.vector <- c()

    id.gene.val <- id.cellline[names(id.cellline) %in% colnames(X_val)]
    id.gene.test <- id.cellline[-(id.gene.val)]

  	g=which(rownames(edgestrength_matrix)==target_gene)

    ###get real genexpression values for the remaining genes (validationset)
      g_real_val <- c()

      for(j in id.gene.val){
        i = g
       g_real_val <- c(g_real_val,expression_matrix[i,j])
     }

      ####prediction of those genes (validationset) with estimated coefficients from learning set

      gr_predict_val <- c()

      for(j in id.gene.val){
        i = g
        g_pr <- paste(rownames(expression_matrix[i,]),j,sep="_")
        gr_predict_val <- c(gr_predict_val, g_pr)
      }

      prediction.vector <- c()

      for(j in id.gene.val){
        i = g

        es <- edgestrength_matrix[i,sort(id.tf)]
        act <- activity_matrix[sort(id.tf) ,j]

        es.act <- as.numeric(es * act)

        vec1 <- as.numeric(c(es.act,1))
        vec2 <- beta.values * vec1
        ex.predict <- sum(vec2)
        prediction.vector <- c(prediction.vector, ex.predict)
      }

      g_real_all <- c(g_real_all, g_real_val)
      prediction_all <- c(prediction_all, prediction.vector)

      pred[,o]=prediction_all
      result.table <- rbind(result.table, c(paste(top_hits, collapse=","),paste(beta.values, collapse=";") ,
                                            o, cor(g_real_all, prediction_all, method="pearson")))

      }
	pred[,(max_parameter_limit+1)]=g_real_all
	rownames(pred)=colnames(X_val)
	colnames(pred)=1:(max_parameter_limit+1)
	colnames(pred)[max_parameter_limit+1]="g_real"
	predictions=c(predictions, list(pred))

	result.table=result.table[-1,]
	rownames(result.table)=1:max_parameter_limit

	result_complete=c(result_complete, list(result.table))

############## Regulator Frequency #######
	regulators<-result.table$TF

	combined<-c()
	test=c()

  	for (ii in 1:parameter_limit){
    	t<-strsplit(as.vector(regulators[ii]), ",")
    	combined<-c(as.vector(combined),as.vector(t))
    	test=c(test, combined[[ii]])
    }
	gene<-as.matrix(table(test))
  	bla<-cbind(gene, gene[,1])
  	bla[,1]=rownames(bla)
  	colnames(bla)<-c("TFs", "Number")
  	tfs_vector=colnames(ES)[ES[target_gene,]>0]

	reg=as.data.frame(tfs_vector)
  	rownames(reg)=reg[,1]
	reg[,2]=rep(0,length(tf_vector))
  	rest=reg[!rownames(reg) %in% rownames(bla),]
  	blabla=rbind(bla, as.matrix(rest))

  	blabla<-blabla[order(blabla[,1], decreasing=FALSE),]
  	blabla=blabla[,-1]
	blabla=as.matrix(blabla)
	table_complete=cbind(table_complete, blabla)
 }}
 result=list(result_complete=result_complete, predictions=predictions, table_complete=table_complete)
 return(result)
}
